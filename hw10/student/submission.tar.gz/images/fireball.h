/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=10x10 fireball fireball.png 
 * Time-stamp: Thursday 04/11/2019, 16:23:38
 * 
 * Image Information
 * -----------------
 * fireball.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FIREBALL_H
#define FIREBALL_H

extern const unsigned short fireball[100];
#define FIREBALL_SIZE 200
#define FIREBALL_LENGTH 100
#define FIREBALL_WIDTH 10
#define FIREBALL_HEIGHT 10

#endif

