/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x15 alien alien.jpg 
 * Time-stamp: Thursday 04/11/2019, 20:35:38
 * 
 * Image Information
 * -----------------
 * alien.jpg 20@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ALIEN_H
#define ALIEN_H

extern const unsigned short alien[300];
#define ALIEN_SIZE 600
#define ALIEN_LENGTH 300
#define ALIEN_WIDTH 20
#define ALIEN_HEIGHT 15

#endif

