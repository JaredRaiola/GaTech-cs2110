/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 spaceship spaceship.jpg 
 * Time-stamp: Monday 04/08/2019, 23:10:34
 * 
 * Image Information
 * -----------------
 * spaceship.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPACESHIP_H
#define SPACESHIP_H

extern const unsigned short spaceship[38400];
#define SPACESHIP_SIZE 76800
#define SPACESHIP_LENGTH 38400
#define SPACESHIP_WIDTH 240
#define SPACESHIP_HEIGHT 160

#endif

