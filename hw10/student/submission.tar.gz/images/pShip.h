/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 pShip pShip.jpg 
 * Time-stamp: Thursday 04/11/2019, 18:48:16
 * 
 * Image Information
 * -----------------
 * pShip.jpg 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PSHIP_H
#define PSHIP_H

extern const unsigned short pShip[225];
#define PSHIP_SIZE 450
#define PSHIP_LENGTH 225
#define PSHIP_WIDTH 15
#define PSHIP_HEIGHT 15

#endif

