Welcome to Alien Defense!
Created by Jared Raiola
�	This program spawns a single enemy who moves down the screen and gets increasingly faster over time.
�	The enemy can spawn at any x coordinate on the screen but will always spawn at the top of the screen (underneath the scorecard).
�	The player has control of a spaceship which moves using up, down, left and right, and can fire using the A button. 
�	The player only has one shot, which does not recharge until the initial shot has left the screen. 
�	The player can move to a little under halfway up the screen, and to the borders of the screen on the left, right and bottom.
�	The goal of this game is to survive as long as possible and rack up the highest score, by destroying aliens.
�	The player gets 20 points every time they defeat an alien.
�	If the enemy makes it to the bottom of the screen, or touches the players ship, the game is over.
Note: Select is the only key which will not advance the game from the title screen,
due to the instructions that said "select must reset to the title screen AT ANY TIME".
